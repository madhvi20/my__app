// src/app.js
const express = require('express');
const bodyParser = require('body-parser');
const userRoutes = require('./routes/userRoutes'); // Import the user routes
const sequelize = require('./config/db');

const app = express();
app.use(bodyParser.json()); // Parse JSON request body

// Use routes, all routes are prefixed with '/api'
app.use('/api', userRoutes);  // Ensure that the '/api' prefix is being used

// Sync models with the database
sequelize.sync()
  .then(() => console.log('Database synchronized'))
  .catch(error => console.error('Error syncing database:', error));

module.exports = app;
// Add this at the bottom of src/app.js
app.use((req, res, next) => {
    res.status(404).json({
      message: "Route not found"
    });
  });
  
