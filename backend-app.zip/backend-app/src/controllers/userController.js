// src/controllers/userController.js
const User = require('../models/userModel');
const Address = require('../models/addressModel');

// Function to create a user and associated address
exports.createUserWithAddress = async (req, res) => {
  try {
    const { name, address } = req.body;

    // Create a new user
    const user = await User.create({ name });

    // Create an address linked to the user
    await Address.create({ address, userId: user.id });

    res.status(201).json({
      message: 'User and address added successfully!',
    });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({
      message: 'Internal server error',
    });
  }
};
