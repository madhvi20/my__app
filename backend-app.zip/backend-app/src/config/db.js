// src/config/db.js
const { Sequelize } = require('sequelize');
require('dotenv').config();

const sequelize = new Sequelize(
  process.env.DB_NAME,     // myapp_db
  process.env.DB_USER,     // myapp_user
  process.env.DB_PASSWORD, // myapp_password
  {
    host: process.env.DB_HOST,    // localhost
    dialect: 'postgres',          // PostgreSQL
    port: process.env.DB_PORT,    // 5432
  }
);

// Test database connection
sequelize.authenticate()
  .then(() => console.log('Connected to PostgreSQL!'))
  .catch(err => console.error('Unable to connect to the database:', err));

module.exports = sequelize;
