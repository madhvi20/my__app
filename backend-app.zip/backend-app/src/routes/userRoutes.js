// src/routes/userRoutes.js
const express = require('express');
const router = express.Router();
const { createUserWithAddress } = require('../controllers/userController');

// POST route for creating a user and their address
router.post('/users', createUserWithAddress);  // The POST route for '/users'

module.exports = router;
